import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CartComponentComponent } from './cart-component/cart-component.component';
import { LoginComponentComponent } from './login-component/login-component.component';
import { MenuComponentComponent } from './menu-component/menu-component.component';
import { SplashScreenComponent } from './splash-screen/splash-screen.component';
import { NavbarComponent } from './navbar/navbar.component';
import { RegisterComponent } from './register/register.component';
import { ItemListService } from './services/item-list.service';
import { FoodServiceService } from './services/food-service.service';
import { CartServiceService } from './services/cart-service.service';

@NgModule({
  declarations: [
    AppComponent,
    MenuComponentComponent,
    LoginComponentComponent,
    CartComponentComponent,
    SplashScreenComponent,
    NavbarComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [
    ItemListService,
    FoodServiceService,
    CartServiceService
  ],
  bootstrap: [
    AppComponent
    ]
})
export class AppModule { }
