import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {

  userModel = new User();
  isValidFormSubmitted = false;
  credentialMsg: string;

  constructor(private userService: UserService,
    private router: Router) { }

  ngOnInit() {
  }

  onSubmit(form: NgForm) { 
    this.isValidFormSubmitted = false;
    if(form.invalid) {
      return; 
    }
    else {
      this.isValidFormSubmitted = true;
      this.userModel = form.value;
      this.userService.registerUser(this.userModel).subscribe(data => {
        alert(data);
        this.router.navigate(['login']);
      }, 
      error=> {
        form.reset();
        this.credentialMsg = 'User with this Email already exists.';
      });
    } 
  }

}