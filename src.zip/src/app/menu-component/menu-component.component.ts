import { Component, OnInit } from '@angular/core';
import { Items } from '../items';
import { FoodServiceService } from '../services/food-service.service';

@Component({
  selector: 'app-menu-component',
  templateUrl: './menu-component.component.html',
  styleUrls: ['./menu-component.component.css']
})
export class MenuComponentComponent implements OnInit {
  foodItems: Array<any>;
  item: Items;
  quantity: any;
  inputNumber: Array<Number>;

  constructor(private foodService: FoodServiceService) { 
    this.inputNumber = new Array<Number>();
  }

  ngOnInit() {
    this.foodService.getFoodItems().subscribe(data =>{
      this.foodItems = data;
    });
  }

  addtoCart(item) {
    this.quantity = this.inputNumber[item.itemId];
    item.quantity = item.quantity - this.quantity;
    this.foodService.addtoCart(item).subscribe(data =>{
      alert(data);
    });
  }

}