import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ItemListService } from '../services/item-list.service';
import { Router, Routes } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { User } from '../user';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})

export class LoginComponentComponent implements OnInit {

  userModel = new User();
  isValidFormSubmitted = false;
  invalidCredentialMsg: string;

  constructor(private userService: UserService, 
    private router: Router, 
    private authService: AuthService) { }
  
  ngOnInit() {
  }

  onSubmit(form: NgForm) { 
    this.isValidFormSubmitted = false;
    if(form.invalid) {
      return; 
    }
    else {
      this.isValidFormSubmitted = true;
      this.userModel = form.value;

      this.userService.loginUser(this.userModel).subscribe(data=> {
        let url =  this.authService.getRedirectUrl(); 
        console.log('Redirect Url:'+ url);
        console.log(data['token']);
        if(data['token']) {
          this.authService.setToken(data['token']);
          this.router.navigate([ url ]);
        }
      }, 
      error=> {
        form.reset();
        this.invalidCredentialMsg = 'Invalid Credentials. Try again.';
      });

      // let email = this.userModel.email;
      // let password = this.userModel.password;

      // this.authService.isUserAuthenticated(email, password).subscribe( authenticated => {

      //   if(authenticated) {
      //     let url =  this.authService.getRedirectUrl(); 
      //     console.log('Redirect Url:'+ url);
      //     this.router.navigate([ url ]);					  
      //   } 
      //   else {
      //     this.invalidCredentialMsg = 'Invalid Credentials. Try again.';
      //     form.reset();
      //   }

      // });
    }
  }

}