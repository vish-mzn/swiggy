import { Component, OnInit } from '@angular/core';
import { CartServiceService } from '../services/cart-service.service';
import { Cart } from '../cart';

@Component({
  selector: 'app-cart-component',
  templateUrl: './cart-component.component.html',
  styleUrls: ['./cart-component.component.css']
})
export class CartComponentComponent implements OnInit {
  cartItems: Array<any>;
  cost: Number;
  cart: Cart;
  price: Number;
  inputNumber: Array<Number>;
  quantity: Number;
  singlePrice: Number;

  constructor(private cartService: CartServiceService) {
    this.inputNumber = new Array<Number>();
   }

  ngOnInit() {
    this.cartService.getCartItems().subscribe(data =>{
      this.cartItems = data;
      console.log(this.cartItems);
    });
    
    
    this.cartService.getTotalCost().subscribe(tcost =>{
      this.cost = tcost;
    });
  }

  removeFromCart(cart) {
    console.log(cart);
    this.quantity = this.inputNumber[cart.id];
    this.price = cart.price;
    this.singlePrice = this.price/cart.quantity;
    cart.quantity = cart.quantity - this.quantity;
    cart.price = cart.quantity*this.singlePrice;

    console.log(cart);
    this.cartService.deleteFromCart(cart).subscribe(data =>{
    console.log(data);
    this.ngOnInit();
    console.log(this.cost);
    });
  }

}