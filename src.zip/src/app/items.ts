export class Items {
    itemId: number;
    name: string;
    price: number;
    quantity: number;
    image: string;
    constructor() { }
}