import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartServiceService {
  constructor(private http: HttpClient) { }

  getCartItems(): Observable<any> {
    return this.http.get('http://localhost:8888/getCart');
  }

  getTotalCost(): Observable<any> {
    return this.http.get('http://localhost:8888/totalCost');
  }
  
  deleteFromCart(cart) {
    return this.http.post('http://localhost:8888/delete',cart,{responseType: 'text'});
  }
}
