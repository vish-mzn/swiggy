import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  
  constructor(private http: HttpClient) { }

  registerUser(user) {
    return this.http.post('http://localhost:8899/api/userservice/register', user, {responseType: 'text'});
  }

  getAllUsers(): Observable<any> {
    return this.http.get('http://localhost:8888/getAllUser');
  }

  loginUser(loginDetail) {
    return this.http.post('http://localhost:8899/api/userservice/login', loginDetail, {responseType: 'text'});
  }
 
}
