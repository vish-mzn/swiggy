import { Injectable } from '@angular/core';
import { User } from '../user';

@Injectable()
export class ItemListService {
      
      createUser(user: User) {
        console.log('UserEmail: ' + user.email);
        console.log('Password: ' + user.password);
      }
}
