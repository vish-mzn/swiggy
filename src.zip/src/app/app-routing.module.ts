import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CartComponentComponent } from './cart-component/cart-component.component';
import { LoginComponentComponent } from './login-component/login-component.component';
import { MenuComponentComponent } from './menu-component/menu-component.component';
import { AppComponent } from './app.component';
import { SplashScreenComponent } from './splash-screen/splash-screen.component';
import { AuthGuardService } from './services/auth-guard.service';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  {path: 'menu', component: MenuComponentComponent, canActivate: [AuthGuardService]},
  {path: 'cart', component: CartComponentComponent, canActivate: [AuthGuardService]},
  {path: 'login', component: LoginComponentComponent},
  {path: 'home', component: SplashScreenComponent},
  {path: 'register', component: RegisterComponent},
  {path: '', redirectTo: '/home', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
