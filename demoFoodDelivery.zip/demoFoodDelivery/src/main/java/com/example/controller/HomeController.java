package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	
	@RequestMapping(value = {"/"})
	private String homepage()
	{
		return "menuScreen";
	}
	
	@RequestMapping("/cart")
	private String cart()
	{
		return "cartScreen";
	}
	
}
