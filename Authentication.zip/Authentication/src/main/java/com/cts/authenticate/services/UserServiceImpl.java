package com.cts.authenticate.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.authenticate.exception.UserAlreadyExistsException;
import com.cts.authenticate.exception.UserNotFoundException;
import com.cts.authenticate.model.User;
import com.cts.authenticate.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository userRepo;
	
	public UserServiceImpl(UserRepository userRepo) {
		super();
		this.userRepo = userRepo;
	}

	public boolean saveUser(User user) throws UserAlreadyExistsException {
		Optional<User> existingUser = userRepo.findByEmail(user.getEmail());
		
		if(existingUser.isPresent()) {
			throw new UserAlreadyExistsException("User with Email already exists");
		}
		userRepo.save(user);
		return true;
	}

	public User findByEmailAndPassword(String email, String password) throws UserNotFoundException {
		User user = userRepo.findByEmailAndPassword(email, password);
		
		if(null == user) {
			throw new UserNotFoundException("UserId and Password mismatch");
		}
		return user;
	}

}