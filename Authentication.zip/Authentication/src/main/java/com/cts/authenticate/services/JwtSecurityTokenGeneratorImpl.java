package com.cts.authenticate.services;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.cts.authenticate.model.User;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class JwtSecurityTokenGeneratorImpl implements SecurityTokenGenerator {

	public Map<String, String> generateToken(User user) {
		String jwtToken = "";
		
		jwtToken = Jwts.builder().setSubject(user.getEmail()).setIssuedAt(new Date())
				.signWith(SignatureAlgorithm.HS384, "secretkey").compact();
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("token", jwtToken);
		map.put("message", "User successfully logged in");
		
		System.out.println(map.get("token"));
		
		return map;
	}

}