package com.cts.authenticate.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cts.authenticate.model.User;

public interface UserRepository extends JpaRepository<User, String>{
	
	@Query("Select u from User u where u.email = (?1) and u.password = (?2)")
	User validate(String email, String password);

	User findByEmailAndPassword(String email, String password);

	Optional<User> findByEmail(String email);

}