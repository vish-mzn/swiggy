package com.cts.authenticate.services;

import com.cts.authenticate.exception.UserAlreadyExistsException;
import com.cts.authenticate.exception.UserNotFoundException;
import com.cts.authenticate.model.User;

public interface UserService {
	
	boolean saveUser(User user) throws UserAlreadyExistsException;
	
	User findByEmailAndPassword(String email, String password) throws UserNotFoundException;
}