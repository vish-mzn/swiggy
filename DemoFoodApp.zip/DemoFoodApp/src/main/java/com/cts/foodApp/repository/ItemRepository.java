package com.cts.foodApp.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.cts.foodApp.bean.Item;

public interface ItemRepository extends CrudRepository<Item, Integer> {
	
	@Query("from Item f where f.name=:name")
	Item findByName(@Param("name") String name);

	@Query("from Item i where i.itemId=:id")
	Item findOne(@Param("id") int id);
}
