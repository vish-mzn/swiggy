package com.cts.foodApp.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.foodApp.bean.Cart;

@Repository
public interface CartRepository extends CrudRepository<Cart, Integer>{
	
	@Query("from Cart c where c.name=:name")
	Cart findByName(@Param("name") String name);

	@Query("select sum(c.price) from Cart c")
	Integer calculateTotalCost();

	@Query("from Cart q where q.id=:id")
	Cart findOne(@Param("id") int id);
}
