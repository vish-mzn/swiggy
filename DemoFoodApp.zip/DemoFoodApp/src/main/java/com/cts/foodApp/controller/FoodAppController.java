 package com.cts.foodApp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.foodApp.bean.Cart;
import com.cts.foodApp.bean.Item;
import com.cts.foodApp.bean.User;
import com.cts.foodApp.service.ItemService;

@RestController
@CrossOrigin
public class FoodAppController {
	
	@Autowired
	ItemService service;
	
	@RequestMapping(value = {"/"})
	String addItem()
	{
		//service.prefill();
		return "a";
	}
	
	@GetMapping(value = "getItems")
	public List<Item> getItemList(final HttpServletRequest request, final HttpServletResponse response)
	{
//		final String authHeader = request.getHeader("authorization");
//		final String token = authHeader.substring(7);
//		String 
		List<Item> itemList = service.getItemList();
		return itemList;
	}
	
	@GetMapping(value = "getCart", produces = "application/json")
	public List<Cart> getCartList()
	{
		List<Cart> cartList = service.getCartList();
		return cartList;
	}
	
//	@GetMapping(value = "getAllUser", produces = "application/json")
//	public List<User> getUserList()
//	{
//		List<User> userList = service.getUserList();
//		return userList;
//	}
	
	@PostMapping(value = "add")
	public ResponseEntity<Map<String, String>> addToCart(@RequestBody Item item)
	{
		ResponseEntity<Map<String, String>> responseEntity;
		Map<String, String> map1 = new HashMap<String, String>();
		String name = item.getName();
		
		if (!service.nameExistsInCart(name)) {
			service.addToCart(item);
			map1.put("message", "addedtocart");
		} else {
			service.updateCart(item);
			map1.put("message", "cart Updated");
		}
		
		responseEntity = new ResponseEntity<Map<String, String>>(map1, HttpStatus.OK);
		return responseEntity;
	}
	
	@GetMapping(value = "totalCost")
	public int getTotalCost() {
		int price = service.getTotalCost();
		
		return price;
	}
	
	@PostMapping(value = "delete")
	public ResponseEntity<Map<String, String>> deleteFromCart(@RequestBody Cart cart) {
		ResponseEntity<Map<String, String>> responseEntity;
		Map<String, String> map1 = new HashMap<String, String>();
		service.deleteFromCart(cart);
		map1.put("message", "Removed from Cart");
		responseEntity = new ResponseEntity<Map<String, String>>(map1, HttpStatus.OK);
		return responseEntity;
	}
	
//	@PostMapping(value = "registeration")
//	public ResponseEntity<String> userRegistration(@RequestBody User user) {
//		ResponseEntity<String> responseEntity;
//		service.userRegistration(user);
//		responseEntity = new ResponseEntity<String>("success", HttpStatus.OK);
//		return responseEntity;
//	}
	
	
	
	
}
