package com.cts.foodApp.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.foodApp.bean.Cart;
import com.cts.foodApp.bean.Item;
import com.cts.foodApp.bean.User;
import com.cts.foodApp.repository.CartRepository;
import com.cts.foodApp.repository.ItemRepository;
import com.cts.foodApp.repository.UserRepository;

@Service
public class ItemService {

	@Autowired
	ItemRepository itemRepository;
	
	@Autowired
	CartRepository cartRepository;
	
	@Autowired
	UserRepository userRepository;
	
//	public void prefill() {
//		Item i1 = new Item(1, "Veg Biryani", 120, 20, "veg-biryani.jpg");
//		Item i2 = new Item(2, "Chicken Biryani", 160, 20, "chicken-biryani.jpg");
//		Item i3 = new Item(3, "Medu Vada", 80, 20, "medu-vada.jpg");
//		Item i4 = new Item(4, "Dosa", 100, 20, "Dosa.jpg");
//		Item i5 = new Item(5, "HamBurger", 110, 20, "burger.jpg");
//		Item i6 = new Item(6, "French fries", 90, 20, "fries.jpg");
//		Item i7 = new Item(7, "Pizza", 150, 20, "pizza.jpg");
//		Item i8 = new Item(8, "Momos", 70, 20, "momo.jpg");
//		itemRepository.save(i1);
//		itemRepository.save(i2);
//		itemRepository.save(i3);
//		itemRepository.save(i4);
//		itemRepository.save(i5);
//		itemRepository.save(i6);
//		itemRepository.save(i7);
//		itemRepository.save(i8);
//	}

	@Transactional
	public List<Item> getItemList() {
		List<Item> itemList = (List<Item>) itemRepository.findAll();
		return itemList;
	}
	
	@Transactional
	public List<Cart> getCartList() {
		List<Cart> cartList = (List<Cart>) cartRepository.findAll();
		return cartList;
	}
	
//	@Transactional
//	public List<User> getUserList() {
//		List<User> userLsit = (List<User>) userRepository.findAll();
// 		return userLsit;
//	}
	
	@Transactional
	public void addToCart(Item item) {
		int id = item.getItemId();
		Item oldItem = itemRepository.findOne(id);
		int price = oldItem.getPrice();
		int totalCost = price * (oldItem.getQuantity() - item.getQuantity());
		
		Cart cart = new Cart();
		cart.setName(item.getName());
		cart.setPrice(totalCost);
		cart.setQuantity(oldItem.getQuantity() - item.getQuantity());
		cartRepository.save(cart);
		
		oldItem.setQuantity(item.getQuantity());
		itemRepository.save(oldItem);
	}
	
	@Transactional
	public boolean nameExistsInCart(String name) {
		boolean result = false;
		try {
			Cart cart = cartRepository.findByName(name);
			System.out.println(cart.getId());
			if (cart.getId() > 0) {
				result = true;
			}
		} catch (NullPointerException e) {
			return false;
		}
		return result;
	}

	@Transactional
	public void updateCart(Item item) {
		int id = item.getItemId();
		Item oldfood = itemRepository.findOne(id);
		int price = oldfood.getPrice();
		int totalCost = price * (oldfood.getQuantity() - item.getQuantity());
		Cart cart = cartRepository.findByName(item.getName());
		cart.setPrice(cart.getPrice() + totalCost);
		cart.setQuantity(cart.getQuantity() + (oldfood.getQuantity() - item.getQuantity()));
		cartRepository.save(cart);
		oldfood.setQuantity(item.getQuantity());

		itemRepository.save(oldfood);
	}

	@Transactional
	public int getTotalCost() {
		int price=0;
		try
		{
	    price = cartRepository.calculateTotalCost();
		}
		catch(NullPointerException e)
		{
			return 0;
		}
		return price;
	}

	@Transactional
	public void deleteFromCart(Cart cart) 
	{
		Item item = itemRepository.findByName(cart.getName());
		Cart oldCart = cartRepository.findOne(cart.getId());
		int price = item.getPrice();
		int quantity = cart.getQuantity();
		int foodNewQuantity = oldCart.getQuantity() - cart.getQuantity();
		item.setQuantity(item.getQuantity() + foodNewQuantity);
		itemRepository.save(item);
		if (quantity == 0) {
			cartRepository.delete(cart);
		} else {
			cart.setPrice(quantity * price);
			cartRepository.save(cart);
		}

	}

//	@Transactional
//	public void userRegistration(User user) {
//		userRepository.save(user);
//	}

	
	

}
