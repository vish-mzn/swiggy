package com.cts.foodApp.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.foodApp.bean.User;

@Repository
public interface UserRepository extends CrudRepository<User, Integer>{

	@Query("from User u where u.email=:email")
	User findByEmail(@Param("email") String email);
	
}
